#Stewart Parker	
#1/2/2021
#Happy Tails

def main():

 print("Welcome to Happy Tails!")
 print("Do you want a Fur-Ever pet? You came to the right place!")
 print("Only a few questions away, you get the pet of your dreams!")
 print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
 
 name=input("What is your name?")
 email=input("What is your email")
 print("Your provided email is this, "+str(email))
 print("Let's get started, "+ str(name))
 print("~~~~~~~~~~~~~~~~~~~~~~~~~~~")
 
 #Prints menu
 menu=["Choose a pet"]
 menu2=["Donate a pet"]
 menu3=["Explore"]
 
 ask=input("Please chooe an option. menu,menu2,menu3")
 print(menu)
 print(menu2)
 print(menu3)
 
 print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
 
 
 pets=["Dog", "Cat", "Hamster", "Gerbil", "Fish"]
 donate=["You want to donate, go to www.HappyTails/donate.com"]
 explore=["Go to the main menu, www.HappyTails/explore.com"]
 
 if ask==("menu"):
  print("Here are the list of pets we have")
  print(pets)
  print("Some may be unavailable for adoption however")
 if ask==("menu2"):
  print(donate)
 if ask==("menu3"):
  print(explore)
  
 pet=input("What pet do you want to adopt? dog, cat, hamster, gerbil, fish, none?")
 trait=input("Choose a characteristic. playful, emotional, sweet, old, none")
  
 dog=["We have a whole list of dogs, but first we need a trait to match you with a perfect pet!"]
 cat=["We have a whole list of cats, but first we need a trait to match you with a perfect pet!"]
 hamster=["We have a whole list of hamsters, but first we need a trait to match you with a perfect pet!"]
 gerbil=["We have a limited supply on gerbils. Please choose another pet!"]
 fish=["We have a low supply of fish. Please choose another pet!"]
 none=["If the pet you want isn't listed for adoption, please visit www.HappyTails/explore.com"]
 none2=["If your trait isn't listed, explore more options. Go to www.HappyTails/explore.com"]
  
 if pet==("dog"):
  print(dog)
 if pet==("cat"):
  print(cat)
 if pet==("hamster"):
  print(hamster)
 if pet==("gerbil"):
  print(gerbil)
 elif pet==("fish"):
  print(fish)
 elif pet==("none"):
  print(none)
 
 print("~~~~~~~~~~~~~~~~~~Your Characteristic~~~~~~~~~~~~~~~~~")
 print(trait)
 
 if trait==("playful"):
  print("How about our wonderful energetic dog Runne. Or our very talented cat Freita. Or even our wonderful fast legged hamster Gertyu.")
 if trait==("sweet"):
  print("How about our lovable dog Asia. She loves hugs and kisses. Or our sweet cat Dawn, who purrs so softly. Or our quiet hamster Ceaser.")
 if trait==("old"):
  print("Dot makes a wonderful service dog. Sertia is the best cat for company. Tigert is a very nice hamster that rolls in his wheel all day and will keep you company.")
 if trait==("emotional"):
  print("Yeller is such a compassionate dog, and he knows when you feel angry, happy, sad!")
 if trait==("none"):
  print(none2)
  
 choice=input("Once you have selected your choice, we will notify you when your new animal is ready for pickup. Would you like a guide to taking care of your pet? yes/no")
 
 website=["www./takecareofyourpets/HappyTails.com"]
 
 if choice==("yes"):
  print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
  print(website)
  print("Thank you, and check your email for pickup times!")
  
 if choice==("no"):
  print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
  print("Thank you, and check your email for pickup times!")
  
 print("~~~~~~~~~~~~~~~~~~~~~Happy Tails Adoption Center~~~~~~~~~~~~~~~~~~~~~~~~")
main()